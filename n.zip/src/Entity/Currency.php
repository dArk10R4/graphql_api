<?php

namespace App\Entity;

class Currency extends BaseModel
{
    protected static $table = "currencies";
  
}