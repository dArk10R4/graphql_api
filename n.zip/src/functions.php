<?php
function dd($a) {
    var_dump($a);
    die();
}